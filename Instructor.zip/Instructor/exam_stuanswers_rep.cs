﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Instructor
{
    public partial class exam_stuanswers_rep : Form
    {
        public exam_stuanswers_rep()
        {
            InitializeComponent();
        }

        private void exam_stuanswers_rep_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            mgr_reports ss = new mgr_reports();
            ss.Show();
        }
    }
}
