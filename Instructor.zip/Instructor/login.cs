﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Instructor
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SqlConnection Conn = new SqlConnection("Data Source=.;Initial Catalog=Examination_System;Integrated Security=True");
            SqlCommand cmd1 = new SqlCommand("mgr_login '" + textBox1.Text + "', '" + textBox2.Text + "'", Conn);
            Conn.Open();
            Convert.ToInt32(cmd1.ExecuteNonQuery());
            Conn.Close();
            SqlDataAdapter sda = new SqlDataAdapter(cmd1);
            DataTable dta = new DataTable();
            sda.Fill(dta);
            if (dta.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                mgr_reports ss1 = new mgr_reports();
                ss1.Show();
            }
            else
            {
                MessageBox.Show("Incorrect name or ID !");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have two textboxes to put " + 
                "your ID and password you've already got since we hierd you!" +
                "and then choose your weather you're a manager or an instructor and login to view our reports");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is our new way to stay connected with our staff, it's Simple, easy, and friendly user interface");
        }

        /*private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is our ITI Application which designed and implemented by ITI students (Samar, Salma, Momen, Hala, and Ahmed)");
        }*/

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection Conn = new SqlConnection("Data Source=.;Initial Catalog=Examination_System;Integrated Security=True");
            SqlCommand cmd2 = new SqlCommand("login_ins '" + textBox1.Text+ "', '" + textBox2.Text + "'", Conn);
            Conn.Open();
            Convert.ToInt32(cmd2.ExecuteNonQuery());
            Conn.Close();
            SqlDataAdapter sda = new SqlDataAdapter(cmd2);
            DataTable dta = new DataTable();
            sda.Fill(dta);
            if (dta.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                Form2 ss = new Form2();
                ss.Show();
                
            }
            else
            {
                MessageBox.Show("Incorrect name or ID !");
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("People develop countries, We develop P.E.O.P.L.E");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Enter your ID and name in the boxes above and then choose either you are an instructor or manager to view your report");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Support Email: ITIinfo@iti.gov.eg");

        }
    }
}
